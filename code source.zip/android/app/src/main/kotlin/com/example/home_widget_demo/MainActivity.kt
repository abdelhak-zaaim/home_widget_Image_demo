package com.example.home_widget_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

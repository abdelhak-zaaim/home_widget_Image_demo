String groupId = 'group.home_widget_demo_group';
String iosWidget = 'home_widget_demo';
String androidWidget = 'CustomHomeView';
